import React from 'react';

function Hero() {
  return (
    <div className='w-full flex '>
      <video src="/src/0716.mp4" autoPlay loop muted>Your Browser Doesn't support HTML5 Video Tag</video>
    </div>
  );
}

export default Hero;
